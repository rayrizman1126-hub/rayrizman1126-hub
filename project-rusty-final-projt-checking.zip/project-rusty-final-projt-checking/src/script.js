// Elements from Project 1
const noBtn = document.getElementById("noBtn");
const yesBtn = document.getElementById("yesBtn");
const result = document.getElementById("result");
const area = document.querySelector(".buttons");
const questionCard = document.getElementById("questionCard");

// Elements from Project 2
const messageCard = document.getElementById("messageCard");
const target = document.getElementById("typed");
const messageText = `Hello, lovey! This is a little appreciation message made especially for you. 
It may be a bit late, but better late than never. 
I really gave my best making this — simple but sincere.

Like a carefully written program — checked and error-free — that’s how genuine my love is for you. 
I may not be the perfect boyfriend, but I’m truly trying, growing, and doing my best for us every day.

I love you — always. ❤️`;

let i = 0;

/* --- Project 1 Logic --- */

// NO button runs away
noBtn.addEventListener("mouseover", moveNo);
noBtn.addEventListener("click", () => {
  result.innerHTML = "You clicked NO?? 😭Why!!! Hinde muna ako mahal no? 😡😒😭That button is broken. Try again😡";
});

function moveNo() {
  const maxX = area.clientWidth - noBtn.clientWidth;
  const maxY = area.clientHeight - noBtn.clientHeight;
  noBtn.style.left = Math.random() * maxX + "px";
  noBtn.style.top = Math.random() * maxY + "px";
}

// YES click: Heart burst + Reveal Project 2
yesBtn.addEventListener("click", () => {
  result.innerHTML = "YES detected ✅ System happiness level: MAX ❤️. So far okay yung pinili mo🥰😘😘.Preparing for next part!";
  heartBurst();

  // Wait a moment for the burst, then switch cards
  setTimeout(() => {
    questionCard.style.display = "none";
    messageCard.style.display = "block";
    messageCard.classList.add("show");
    typeWriter(); // Start Project 2 typing
  }, 2000);
});

// Floating background hearts (Project 1)
function spawnHeart() {
  const h = document.createElement("div");
  h.className = "heart-bg";
  h.innerHTML = "❤️";
  h.style.left = Math.random() * 100 + "vw";
  h.style.animationDuration = (4 + Math.random() * 4) + "s";
  document.body.appendChild(h);
  setTimeout(() => h.remove(), 8000);
}
setInterval(spawnHeart, 500);

// Heart burst function (Project 1)
function heartBurst() {
  for (let j = 0; j < 20; j++) {
    const h = document.createElement("div");
    h.className = "heart-bg";
    h.innerHTML = "💖";
    h.style.left = "50vw";
    h.style.fontSize = "24px";
    h.style.animationDuration = (2 + Math.random() * 2) + "s";
    document.body.appendChild(h);
    setTimeout(() => h.remove(), 4000);
  }
}

/* --- Project 2 Logic --- */

function typeWriter() {
  if (i < messageText.length) {
    target.innerHTML += messageText[i] === "\n" ? "<br>" : messageText[i];
    i++;
    setTimeout(typeWriter, 28);
  }
}

// Click to drop hearts on the message box (Project 2)
messageCard.addEventListener("click", (e) => {
  const heart = document.createElement("div");
  heart.className = "heart";
  heart.innerHTML = "❤️";
  heart.style.left = e.offsetX + "px";
  heart.style.top = e.offsetY + "px";
  messageCard.appendChild(heart);
  setTimeout(() => heart.remove(), 3000);
});