# project rusty final projt. checking.

A Pen created on CodePen.

Original URL: [https://codepen.io/ray-rizman/pen/ZYOZaKp](https://codepen.io/ray-rizman/pen/ZYOZaKp).

